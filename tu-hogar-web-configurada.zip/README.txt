TÚ HOGAR — WEB DE PRESUPUESTOS

1. Abre index.html en un navegador.
2. La imagen original del folleto está en assets/flyer.png.
3. Para recibir las solicitudes directamente por WhatsApp:
   - Abre index.html con un editor de texto.
   - Busca: const BUSINESS_WHATSAPP = "";
   - Pon tu número en formato internacional, sin +, espacios ni guiones.
     Ejemplo: const BUSINESS_WHATSAPP = "34600123456";
4. Guarda y vuelve a abrir la web.

La web funciona sin servidor: el formulario prepara una solicitud y, si configuras WhatsApp,
abre una conversación con el mensaje ya escrito.
